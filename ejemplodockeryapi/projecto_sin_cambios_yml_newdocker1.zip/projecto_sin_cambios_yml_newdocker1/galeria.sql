/*
-- Query: SELECT * FROM jardineria.galeria
LIMIT 0, 1000

-- Date: 2023-01-23 14:25
*/
INSERT INTO `` (`id`,`titulo`,`url_img`,`codigo_empleado`) VALUES (1,'Imagen 1','/imagen1.jpg',1);
INSERT INTO `` (`id`,`titulo`,`url_img`,`codigo_empleado`) VALUES (2,'Imagen2','/imagen2.jpg',1);
INSERT INTO `` (`id`,`titulo`,`url_img`,`codigo_empleado`) VALUES (3,'Imagen3','/imagen3.jpg',4);
INSERT INTO `` (`id`,`titulo`,`url_img`,`codigo_empleado`) VALUES (4,'Imagen4','/imagen4.jpg',7);

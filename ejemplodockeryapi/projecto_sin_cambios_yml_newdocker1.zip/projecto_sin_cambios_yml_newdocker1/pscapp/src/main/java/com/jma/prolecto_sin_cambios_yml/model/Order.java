package com.jma.prolecto_sin_cambios_yml.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Order {
    private double price = 50;
    private String currency = "USD";
    private String method;
    private String intent = "sale";
    private String description = "Payment";
}

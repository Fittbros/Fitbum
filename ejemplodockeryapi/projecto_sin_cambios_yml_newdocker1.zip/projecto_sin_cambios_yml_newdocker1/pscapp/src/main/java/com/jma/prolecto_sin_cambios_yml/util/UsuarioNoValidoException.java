package com.jma.prolecto_sin_cambios_yml.util;

public class UsuarioNoValidoException extends Exception{
    public UsuarioNoValidoException(String message) {
        super(message);
    }
}

package com.jma.prolecto_sin_cambios_yml.util;

public class ResourceNotFoundException extends Exception{
    public ResourceNotFoundException(String message) {
        super(message);
    }
}

package com.jma.prolecto_sin_cambios_yml.util;

public class InvalidReCaptchaException extends Exception{
    public InvalidReCaptchaException(String message) {
        super(message);
    }
}

package com.jma.prolecto_sin_cambios_yml.repository;



import com.jma.prolecto_sin_cambios_yml.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
}

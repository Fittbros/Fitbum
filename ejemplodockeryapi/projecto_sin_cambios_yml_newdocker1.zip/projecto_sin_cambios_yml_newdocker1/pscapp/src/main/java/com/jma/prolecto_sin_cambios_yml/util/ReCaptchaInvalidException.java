package com.jma.prolecto_sin_cambios_yml.util;

public class ReCaptchaInvalidException extends Exception{
    public ReCaptchaInvalidException(String message) {
        super(message);
    }
}

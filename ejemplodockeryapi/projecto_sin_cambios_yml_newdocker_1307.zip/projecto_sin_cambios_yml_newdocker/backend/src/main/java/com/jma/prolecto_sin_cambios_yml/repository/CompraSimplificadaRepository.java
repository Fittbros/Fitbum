package com.jma.prolecto_sin_cambios_yml.repository;


import com.jma.prolecto_sin_cambios_yml.model.CompraSimplificada;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CompraSimplificadaRepository extends JpaRepository<CompraSimplificada,Integer>{
}

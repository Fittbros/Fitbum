package com.cfc.ejemplo20_firebase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.os.Bundle;
import android.util.Log;

import com.cfc.ejemplo20_firebase.holders.CervezasAdapter;
import com.cfc.ejemplo20_firebase.models.Cerveza;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Conectar con la base de datos
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // Agregar nueva cerveza
        Map<String, Object> cerveza = new HashMap<>();
        cerveza.put("marca", "Estrella Galicia");
        cerveza.put("precio", 2.50);

        // Add a new document with a generated ID
        db.collection("cervezas")
                .add(cerveza)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d("", "DocumentSnapshot added with ID: " + documentReference.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(Exception e) {
                        Log.w("", "Error adding document", e);
                    }
                });

        // Consultar todos
        final List<Cerveza> lista = new ArrayList<>();
        db.collection("cervezas")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String marca = document.get("marca").toString();
                                double precio = (double)document.get("precio");
                                lista.add(new Cerveza(marca, precio));
                                //Log.d("", document.getId() + " => " + document.getData());
                            }
                            /*System.out.println("Lista de cervezas");
                            System.out.println("-----------------");
                            System.out.println(lista);*/
                            //mostrarDatos(lista);
                        } else {
                            Log.w("", "Error getting documents.", task.getException());
                        }
                    }

                });

        // Consultar uno
        final List<Cerveza> lista2 = new ArrayList<>();
        db.collection("cervezas")
                .whereEqualTo("marca", "1906")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                String marca = document.get("marca").toString();
                                double precio = (double)document.get("precio");
                                lista2.add(new Cerveza(marca, precio));
                                //Log.d("", document.getId() + " => " + document.getData());
                            }
                            /*System.out.println("Lista de cervezas");
                            System.out.println("-----------------");
                            System.out.println(lista);*/
                            mostrarDatos(lista2);
                        } else {
                            Log.w("", "Error getting documents.", task.getException());
                        }
                    }

                });

        //Delete item
        db.collection("cervezas").document("x2HmpTxLgGNuIeJycxoQ")
                .delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("", "DocumentSnapshot successfully deleted!");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure( Exception e) {
                        Log.w("", "Error deleting document", e);
                    }
                });

        //Update item
        cerveza = new HashMap<>();
        cerveza.put("marca", "Estrella Galicia");
        cerveza.put("precio", 3.00);
        db.collection("cervezas").document("t0AiJ3RHrLtUGzugEwSe")
                .update(cerveza)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.d("", "DocumentSnapshot successfully update!");
                        System.out.println("Cerveza modificada");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure( Exception e) {
                        Log.w("", "Error deleting document", e);
                    }
                });

    }

    private void mostrarDatos(List<Cerveza> lista){
        RecyclerView recyclerView = findViewById(R.id.lstCervezas);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(new CervezasAdapter(lista, R.layout.item_lista));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
    }
}
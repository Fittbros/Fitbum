package com.cfc.ejemplo20_firebase.holders;

import android.view.View;
import android.widget.TextView;

import com.cfc.ejemplo20_firebase.R;

import androidx.recyclerview.widget.RecyclerView;

public class CervezaHolder extends RecyclerView.ViewHolder {

    // Almacenamos item_lista.xml
    private View view;


    public CervezaHolder(View itemView) {
        super(itemView);
        view = itemView;
    }

    public void setMarca(String marca){
        TextView labelMarca = view.findViewById(R.id.marca);
        labelMarca.setText(marca);
    }

    public void setPrecio(double precio){
        TextView labelPrecio = view.findViewById(R.id.precio);
        labelPrecio.setText(String.valueOf(precio));
    }
}

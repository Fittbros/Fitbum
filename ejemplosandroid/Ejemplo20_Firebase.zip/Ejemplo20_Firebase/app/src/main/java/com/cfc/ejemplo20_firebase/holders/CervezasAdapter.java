package com.cfc.ejemplo20_firebase.holders;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.cfc.ejemplo20_firebase.models.Cerveza;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CervezasAdapter extends RecyclerView.Adapter<CervezaHolder> {

    private List<Cerveza> cervezas;
    private int itemLayout;

    public CervezasAdapter(List<Cerveza> cervezas, int itemLayout) {
        this.cervezas = cervezas;
        this.itemLayout = itemLayout;
    }

    @Override
    public CervezaHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(itemLayout,parent,false);
        return new CervezaHolder(view);
    }

    @Override
    public void onBindViewHolder(CervezaHolder holder, int position) {
        Cerveza cerveza = cervezas.get(position);
        holder.setMarca(cerveza.getMarca());
        holder.setPrecio(cerveza.getPrecio());
    }

    @Override
    public int getItemCount() {
        return cervezas.size();
    }
}

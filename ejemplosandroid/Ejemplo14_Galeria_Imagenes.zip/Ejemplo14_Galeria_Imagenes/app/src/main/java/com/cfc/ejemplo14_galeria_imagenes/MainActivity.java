package com.cfc.ejemplo14_galeria_imagenes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Gallery;
import android.widget.ImageView;

import com.cfc.ejemplo14_galeria_imagenes.adapters.ImageAdapter;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Crear un array con todas las imagenes
        Integer[] imagenes = {R.drawable.pic1,R.drawable.pic2,R.drawable.pic3,R.drawable.pic4,
                R.drawable.pic5,R.drawable.pic6,R.drawable.pic7};

        // Acceder a la galeria
        Gallery miGaleria = findViewById(R.id.galeria);

        // Asociamos el adapter a la galeria
        miGaleria.setAdapter(new ImageAdapter(this,imagenes));

        miGaleria.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ImageView imagen = findViewById(R.id.imagen);
                imagen.setImageResource(imagenes[position]);
            }
        });
    }


}
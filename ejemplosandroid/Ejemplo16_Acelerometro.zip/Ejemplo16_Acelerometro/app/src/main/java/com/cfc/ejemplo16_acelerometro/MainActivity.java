package com.cfc.ejemplo16_acelerometro;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    SensorManager sensorManager = null;
    double nuevoX = 0;
    double nuevoY = 0;
    double nuevoZ = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        List<Sensor> sensores = sensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER);
        if (sensores.size() > 0){
            sensorManager.registerListener(this, sensores.get(0),SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onStop() {
        // Antes de parar la actividad eliminamos el listener
        sensorManager.unregisterListener(this);
        super.onStop();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        nuevoX = event.values[0];
        nuevoY = event.values[1];
        nuevoZ = event.values[2];

        // Recuperar el acceso a las etiquetas
        TextView labelX = findViewById(R.id.txt_X);
        TextView labelY = findViewById(R.id.txt_Y);
        TextView labelZ = findViewById(R.id.txt_Z);

        // Mostrar en cada etiqueta la nueva coordenada
        labelX.setText("Acelerometro X: " + nuevoX);
        labelY.setText("Acelerometro Y: " + nuevoY);
        labelZ.setText("Acelerometro Z: " + nuevoZ);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
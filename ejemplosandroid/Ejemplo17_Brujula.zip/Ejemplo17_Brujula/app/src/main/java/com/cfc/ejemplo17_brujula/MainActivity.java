package com.cfc.ejemplo17_brujula;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    SensorManager sensorManager = null;

    SensorEventListener listener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            TextView heading = findViewById(R.id.heading);
            TextView pitch = findViewById(R.id.pitch);
            TextView roll = findViewById(R.id.roll);

            double headingValue = event.values[0];
            double pitchValue = event.values[1];
            double rollValue = event.values[2];

            heading.setText("Heading: " + headingValue);
            pitch.setText("Pitch: " + pitchValue);
            roll.setText("Roll: " + rollValue);
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        int sensorType = Sensor.TYPE_MAGNETIC_FIELD;
        sensorManager.registerListener(listener, sensorManager.getDefaultSensor(sensorType), SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onStop() {
        sensorManager.unregisterListener(listener);
        super.onStop();
    }


}
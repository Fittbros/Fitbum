package com.cfc.ejemplo12_sqlite.persistencia;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class GestionBBDD extends SQLiteOpenHelper {

    public GestionBBDD(Context context, String name,
                       SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Se utiliza para crear la base de datos por primera vez
        db.execSQL("drop table if exists Helados");

        db.execSQL("create table Helados (ID INTEGER PRIMARY KEY, " +
                "Sabor TEXT, Precio REAL, Formato TEXT)");

        // Insertar datos de inicio
        db.execSQL("insert into Helados values (1,'Fresa',2.5,'Tarrina pequeña')");
        db.execSQL("insert into Helados values (2,'Chocolate',3.2,'Cono grande')");
        db.execSQL("insert into Helados values (3,'Pistacho',3.0,'Tarrina mediana')");
        db.execSQL("insert into Helados values (4,'Vainilla',2.8,'Cono pequeño')");
        db.execSQL("insert into Helados values (5,'Cafe',4.3,'Tarrina grande')");
        db.execSQL("insert into Helados values (6,'Nata',3.5,'Cono mediano')");

        /*

        db.execSQL("create table Helados (ID INTEGER PRIMARY KEY AUTOINCREMENT, Sabor TEXT, Precio REAL, Formato TEXT)");          // insertar datos de inicio         db.execSQL("insert into Helados ('Sabor', 'Precio', 'Formato') values ('Fresa',2.5,'Tarrina pequeña')");         db.execSQL("insert into Helados ('Sabor', 'Precio', 'Formato') values ('Chocolate',2.1,'Cono grande')");         db.execSQL("insert into Helados ('Sabor', 'Precio', 'Formato') values ('Vainilla',3.9,'Tarrina mediana')");         db.execSQL("insert into Helados ('Sabor', 'Precio', 'Formato') values ('Cafe',4.88,'Tarrina mini')");         db.execSQL("insert into Helados ('Sabor', 'Precio', 'Formato') values ('Nata',5.98,'Tarrina pequeña')"); 
         */
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Se utiliza para modificar la estructura de la BBDD
    }
}

package com.cfc.ejemplo12_sqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;

import com.cfc.ejemplo12_sqlite.persistencia.GestionBBDD;

public class MainActivity extends AppCompatActivity {

    TextView etiqueta = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Localizar la etiqueta en la UI
        etiqueta = findViewById(R.id.label);

        // Crear la BBDD
        GestionBBDD gestionBBDD = new GestionBBDD(this,"MiDB",null,1);

        // Abrir la BBDD
        SQLiteDatabase db = gestionBBDD.getWritableDatabase();

        // Borrar
        db.execSQL("delete from Helados where ID=?",new String[]{"7"});

        // Otra forma de borrar
        String condicion = "ID=?";
        String[] argumentos = new String[]{"8"};
        db.delete("Helados",condicion,argumentos);

        // Insertar
        db.execSQL("insert into Helados values (7,'Avellana',2.5,'Tarrina pequeña')");

        // Otra forma de insertar
        ContentValues values = new ContentValues();
        values.put("ID", 8);
        values.put("Sabor", "Caramelo salado");
        values.put("Precio", 4.3);
        values.put("Formato", "Cono grande");
        db.insert("Helados",null,values);

        // Modificar, update
        db.execSQL("update Helados set Precio = ? where ID = ?", new String[]{"6.5","1"});

        // Otra forma
        values = new ContentValues();
        values.put("Precio", 4.3);
        condicion = "ID=?";
        argumentos = new String[]{"2"};
        db.update("Helados",values,condicion,argumentos);

        // Mostrar todos los helados
        Cursor c1 = db.rawQuery("select * from Helados", null);

        pinta(c1);

        // Buscar helado de chocolate
        String[] parametros = {"Chocolate"};
        c1 = db.rawQuery("select * from Helados where Sabor = ?", parametros);

        // Otra forma de lanzar queries
        String[] campos = new String[]{"ID","Sabor","Precio","Formato"};
        c1 = db.query("Helados",campos,"Sabor = ?",parametros,
                null,null,null);




    }

    private void pinta(Cursor c1) {
        while (c1.moveToNext()) {
            String id = c1.getString(0);
            String sabor = c1.getString(1);
            Double precio = c1.getDouble(2);
            String formato = c1.getString(3);

            etiqueta.setText(etiqueta.getText() + " " + id +
                    " " + sabor + " " + precio + " " + formato + "\n");
        }
    }
}
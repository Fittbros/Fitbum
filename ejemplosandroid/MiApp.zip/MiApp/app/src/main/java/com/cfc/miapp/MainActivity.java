package com.cfc.miapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.cfc.miapp.fragments.CursosFragment;
import com.cfc.miapp.fragments.ProfesoresFragment;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {

    DrawerLayout drawerLayout = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.appbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_nav_menu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.navview);

        // Escuchar cuando se pulsa el navigationView
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                // Segun la opcion seleccionada del menu, mostraremos
                // su fragment correspondiente
                Fragment fragment = null;
                boolean cambiarFragment = false;

                switch (menuItem.getItemId()){
                    case R.id.menu_seccion_1:
                        fragment = new ProfesoresFragment();
                        cambiarFragment = true;
                        break;
                    case R.id.menu_seccion_2:
                        fragment = new CursosFragment();
                        cambiarFragment = true;
                        break;
                }

                if (cambiarFragment){
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.content_frame, fragment).commit();

                    menuItem.setChecked(true);
                    getSupportActionBar().setTitle(menuItem.getTitle());
                }

                drawerLayout.closeDrawers();

                return true;
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                drawerLayout.openDrawer(GravityCompat.START);
                return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
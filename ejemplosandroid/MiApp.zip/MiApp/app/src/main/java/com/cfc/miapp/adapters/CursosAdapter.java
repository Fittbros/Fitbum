package com.cfc.miapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.cfc.miapp.R;
import com.cfc.miapp.models.Curso;

import java.util.List;


public class CursosAdapter extends BaseAdapter {

    private List<Curso> cursos;
    private Context context;

    public CursosAdapter(List<Curso> cursos, Context context) {
        this.cursos = cursos;
        this.context = context;
    }

    @Override
    public int getCount() {
        return cursos.size();
    }

    @Override
    public Object getItem(int position) {
        return cursos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Curso item = cursos.get(position);
        MiViewHolder holder = null;

        if (convertView == null){
            convertView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.row_cursos,parent,false);
            holder = new MiViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (MiViewHolder) convertView.getTag();
        }

        holder.nombre.setText(item.getNombre());
        holder.horas.setText(String.valueOf(item.getHoras()) + " horas");
        holder.precio.setText(String.valueOf(item.getPrecio()) + " €");

        return convertView;
    }

    public class MiViewHolder {
        // Recuperar las tres etiquetas de row_cursos
        public TextView nombre;
        public TextView horas;
        public TextView precio;

        public MiViewHolder(View itemView){
            nombre = itemView.findViewById(R.id.nombre_curso);
            horas = itemView.findViewById(R.id.horas_curso);
            precio = itemView.findViewById(R.id.precio_curso);
        }
    }
}

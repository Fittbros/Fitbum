package com.cfc.miapp.persistence;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.cfc.miapp.models.Curso;

import java.util.ArrayList;
import java.util.List;

public class CursosDAO {

    // Conexion
    SQLiteDatabase database = null;
    Context context = null;

    public CursosDAO(Context context) {
        this.context = context;
    }

    private void abrirConexion(){
        GestionBBDD gestionBBDD = new GestionBBDD(context, "CFCDB",null,1);
        database = gestionBBDD.getWritableDatabase();
    }

    private void cerrarConexion(){
        database.close();
    }

    public List<Curso> consultarTodos(){
        abrirConexion();
        List<Curso> lista = new ArrayList<>();

        Cursor cursor = database.rawQuery("select * from Cursos", null);

        while(cursor.moveToNext()){
            lista.add(new Curso(cursor.getString(1),
                    cursor.getInt(2), cursor.getDouble(3)));
        }
        cerrarConexion();
        return lista;
    }
}

package com.cfc.miapp.persistence;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class GestionBBDD extends SQLiteOpenHelper {

    public GestionBBDD(Context context, String name,
                       SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Se utiliza para crear la base de datos por primera vez
        db.execSQL("drop table if exists Cursos");

        db.execSQL("create table Cursos (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "NOMBRE TEXT, HORAS INTEGER, PRECIO REAL)");

        // Insertar datos de inicio
        db.execSQL("insert into Cursos ('NOMBRE','HORAS','PRECIO') values " +
                "('HTML',30,120.50)");
        db.execSQL("insert into Cursos ('NOMBRE','HORAS','PRECIO') values " +
                "('CSS',20,90)");
        db.execSQL("insert into Cursos ('NOMBRE','HORAS','PRECIO') values " +
                "('Angular',50,360)");
        db.execSQL("insert into Cursos ('NOMBRE','HORAS','PRECIO') values " +
                "('React',60,430)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Se utiliza para modificar la estructura de la BBDD
    }
}

package com.cfc.miapp.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.cfc.miapp.R;
import com.cfc.miapp.models.Profesor;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ProfesoresAdapter extends RecyclerView.Adapter<ProfesoresAdapter.MiViewHolder> {

    private List<Profesor> profesores;
    private int itemLayout;

    public ProfesoresAdapter(List<Profesor> profesores, int itemLayout) {
        this.profesores = profesores;
        this.itemLayout = itemLayout;
    }


    @Override
    public MiViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext())
                .inflate(itemLayout,parent,false);
        return new MiViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ProfesoresAdapter.MiViewHolder holder, int position) {
        Profesor profesor = profesores.get(position);
        holder.nombre.setText(profesor.getNombre());
        holder.perfil.setText(profesor.getPerfil());
        holder.experiencia.setText(profesor.getExperiencia());
    }

    @Override
    public int getItemCount() {
        return profesores.size();
    }

    public class MiViewHolder extends RecyclerView.ViewHolder{
        // Recuperar las tres etiquetas de row_profesores
        public TextView nombre;
        public TextView perfil;
        public TextView experiencia;

        public MiViewHolder(View itemView){
            super(itemView);

            nombre = itemView.findViewById(R.id.nombre_profe);
            perfil = itemView.findViewById(R.id.perfil_profe);
            experiencia = itemView.findViewById(R.id.experiencia_profe);
        }
    }
}

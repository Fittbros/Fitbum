package com.cfc.ejemplo1_helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SaludoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saludo);

        // Localizar la etiqueta
        TextView etiqueta = findViewById(R.id.lblMensaje);

        // Recuperar el nombre del usuario
        String nombre = getIntent().getExtras().getString("nameUser");

        // Creamos un mensaje y lol mostramos en la etiqueta
        etiqueta.setText("Bienvenido " + nombre + " !!!");
    }
}
package com.cfc.ejemplo1_helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Localizar los controles
        EditText cajaTexto = findViewById(R.id.txtNombre);
        Button boton = findViewById(R.id.boton);

        // Detectar cuando se pulsa el boton
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegacion, tengo la intencion
                // de ir desde MainActivity a SaludoActivity
                Intent intent = new Intent(MainActivity.this,
                        SaludoActivity.class);

                // Recuperar el nombre escrito por el usuario
                String nombre = cajaTexto.getText().toString();

                // Crear un objeto Bundle donde almacenar los datos
                // que queremos enviar a la otra Activity
                Bundle bundle = new Bundle();
                bundle.putString("nameUser", nombre);

                // Adjuntar el bundle al intent
                intent.putExtras(bundle);

                // Iniciamos la nueva activity
                startActivity(intent);
            }
        });
    }
}
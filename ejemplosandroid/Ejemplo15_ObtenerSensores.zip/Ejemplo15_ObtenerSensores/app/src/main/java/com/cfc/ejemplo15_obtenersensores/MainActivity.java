package com.cfc.ejemplo15_obtenersensores;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView etiqueta = findViewById(R.id.label);

        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        // Obtener la lista de todos los sensores disponibles en mi dispositivo
        List<Sensor> listaSensores = sensorManager.getSensorList(Sensor.TYPE_ALL);

        // Recorrer la lista y mostrarlos en la etiqueta
        for (Sensor sensor: listaSensores) {
            etiqueta.append(sensor.getName() + "\n");
        }
    }
}
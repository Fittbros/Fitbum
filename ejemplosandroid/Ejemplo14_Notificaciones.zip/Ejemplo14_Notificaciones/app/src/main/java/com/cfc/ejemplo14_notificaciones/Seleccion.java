package com.cfc.ejemplo14_notificaciones;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class Seleccion extends DialogFragment {

    final String[] items = {"Movil", "Casa", "Vecino"};

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("SELECCIONA WIFI");

        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                System.out.println("Wifi seleccionada " + items[which]);
            }
        });

        return builder.create();
    }
}

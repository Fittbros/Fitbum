package com.cfc.ejemplo14_notificaciones;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void mostrar(View view){
        switch (view.getId()){
            case R.id.toast_defecto:
                Toast toast1 = Toast.makeText(getApplicationContext(),
                        "Notificacion defecto", Toast.LENGTH_SHORT);
                toast1.show();
                break;
            case R.id.toast_personalizado:
                Toast toast2 = new Toast(getApplicationContext());
                LayoutInflater inflater = getLayoutInflater();
                View layout = inflater.inflate(R.layout.mi_toast, findViewById(R.id.lytToast));
                toast2.setDuration(Toast.LENGTH_LONG);
                toast2.setView(layout);
                toast2.show();
                break;
            case R.id.toast_barra_estado:
                int notifyID = 1;
                String CHANNEL_ID = "my_channel_01";// The id of the channel.
                CharSequence name = getString(R.string.channel_name);// The user-visible name of the channel.
                int importance = NotificationManager.IMPORTANCE_HIGH;
                NotificationChannel mChannel = new NotificationChannel(CHANNEL_ID, name, importance);

                // Create a notification and set the notification channel.
                Notification notification = new Notification.Builder(MainActivity.this)
                        .setContentTitle("New Message")
                        .setContentText("You've received new messages.")
                        .setSmallIcon(android.R.drawable.stat_sys_warning)
                        .setChannelId(CHANNEL_ID)
                        .build();

                NotificationManager mNotificationManager =
                        (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                mNotificationManager.createNotificationChannel(mChannel);

                // Issue the notification.
                mNotificationManager.notify(notifyID , notification);
                break;
            case R.id.dialogo_alerta:
                Alerta alerta = new Alerta();
                FragmentManager fm = getSupportFragmentManager();
                alerta.show(fm, "Ventana");
                break;
            case R.id.dialogo_confirmacion:
                Confirmacion confirmacion = new Confirmacion();
                fm = getSupportFragmentManager();
                confirmacion.show(fm, "Ventana");
                break;
            case R.id.dialogo_seleccion:
                Seleccion seleccion = new Seleccion();
                fm = getSupportFragmentManager();
                seleccion.show(fm, "Ventana");
                break;
        }
    }
}